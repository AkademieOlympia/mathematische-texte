# EABC: Gerichteter Replikationstest

Intervall: 100000 <= p < 500000. Seed: 20260913. B = 10000.

## Ergebnis

- N = 31946; Start/Ende: B/C.
- S_obs = -842; mittlere Omega = -0.0263586276.
- Geschätzter Nullmittelwert von S = -618.8658; von Omega = -0.0193734598.
- K = 601; p_MC,less = 602/10001 = 0.0601939806.
- Vorab festgelegtes Kriterium: K <= 99 (alpha = 0.01).
- Ergebnis: gerichtete Replikationsbedingung NICHT ERFÜLLT.
- Alle 10000 Prüfungen auf Pfadlänge, Endpunkte und Bigram-Invarianz bestanden.
- Insgesamt 26861 Pfadversuche; Mittel 2.6861.
- Laufzeit: 418.70 Sekunden.

Ein nicht erfülltes Kriterium beweist weder die Abwesenheit höherer Strukturen noch, dass der explorative Befund ein Artefakt war. Die Abweichung weist weiter nach unten, erreicht aber das vorab gesetzte Niveau nicht.

## Durchführung und Grenzen

Python: 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ]
Plattform: Linux-6.18.35-x86_64-with-glibc2.39
Start UTC: 2026-09-13T15:16:11.712044+00:00
SHA256 Skript: 2090f8c88890c91c70f2e3a54938927b0a3463f202de2ca604f9a19e622dd8e2

Standardbibliothek-Adaption des übergebenen Codes. Gleiches Sieb für das feste Intervall, identische lokale Reihenfolge E,A,B,C, gleicher Rejection-Shuffle und gleiche Zufallsaufrufreihenfolge. Ergänzt wurden vorangestelltes Laufzeit-/Hashprotokoll, ganzzahlige Einzelwertdatei und zusätzliche Endpunkt-/Längenprüfungen. Keine Änderung der Hypothese oder Schwelle nach Datensichtung. Ausschließlich intervallinterne Paare und Tripel. Kein optionaler Zwischenstopp, kein Fallback, kein Seed-Neustart.

Der Freeze wurde unmittelbar vor diesem Lauf lokal protokolliert; dies ist keine externe Präregistrierung. Die SageMath-10.5-Solver wurden nicht ausgeführt.

## Dateien

- replication.py: tatsächlich ausgeführtes Skript
- freeze.json: vor Datenauswertung geschriebene Metadaten
- result.json: Ergebnis mit vollständiger Bigram-Matrix
- null_replicates.csv: alle 10000 ganzzahligen Nullstatistiken und Versuchszahlen

Der Endzähler und die Summe der Nullstatistiken wurden nach Abschluss unabhängig aus der CSV erneut geprüft. Der Skripthash stimmt weiterhin mit dem vorab geschriebenen Hash überein.
