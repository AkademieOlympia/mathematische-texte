import random, sys, platform, hashlib, json, time
from pathlib import Path
from datetime import datetime, timezone
RANDOM_SEED = 20260913
B_REPS = 10000
random.seed(RANDOM_SEED)
root = Path(__file__).resolve().parent
metadata = dict(seed=RANDOM_SEED, B=B_REPS, max_attempts=10000, low=100000, high=500000,
 python=sys.version, platform=platform.platform(), started_utc=datetime.now(timezone.utc).isoformat(),
 sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), decision='K <= 99',
 note='Standard-library adaptation; same local-list rejection shuffle and RNG order as supplied code; integer sums; interval-internal tuples only.')
(root/'freeze.json').write_text(json.dumps(metadata,indent=2))
print(json.dumps(metadata), flush=True)
started=time.monotonic()
def sieve_primes_range(low, high):
    sieve = bytearray([1]) * (high // 2)
    for i in range(1, int(high**0.5) // 2 + 1):
        if sieve[i]:
            val = 2*i+1
            start = val*val//2
            sieve[start::val] = bytearray(len(sieve[start::val]))
    primes = [2] if low <= 2 else []
    for i in range(max(1, low//2), high//2):
        if sieve[i]:
            val=2*i+1
            if val>=low: primes.append(val)
    return primes
V4_ELEMS = ['E', 'A', 'B', 'C']
V4_MULT = {
    ('E', 'E'): 'E', ('E', 'A'): 'A', ('E', 'B'): 'B', ('E', 'C'): 'C',
    ('A', 'E'): 'A', ('A', 'A'): 'E', ('A', 'B'): 'C', ('A', 'C'): 'B',
    ('B', 'E'): 'B', ('B', 'A'): 'C', ('B', 'B'): 'E', ('B', 'C'): 'A',
    ('C', 'E'): 'C', ('C', 'A'): 'B', ('C', 'B'): 'A', ('C', 'C'): 'E',
}

c_rows = [[1,1,1,1],[1,-1,1,-1],[1,-1,-1,1],[1,1,-1,-1]]
c_cocycle = {(g,h):c_rows[i][j] for i,g in enumerate(V4_ELEMS) for j,h in enumerate(V4_ELEMS)}
omega_table = {(g,h,k):c_cocycle[g,h]*c_cocycle[V4_MULT[g,h],k] for g in V4_ELEMS for h in V4_ELEMS for k in V4_ELEMS}
def generate_eulerian_shuffle_strict(sequence, max_attempts=10000):
    """
    Erzeugt einen gleichverteilten Pfad über die Menge aller Sequenzen 
    mit identischem Startknoten und identischen Übergangszahlen C_gh 
    mittels Rejection Sampling zufälliger lokaler Kantenpermutationen.
    """
    N = len(sequence)
    adj = {g: [] for g in V4_ELEMS}
    for i in range(N - 1):
        adj[sequence[i]].append(sequence[i+1])
    
    start_node = sequence[0]
    end_node = sequence[-1]
    
    for attempt in range(1, max_attempts + 1):
        temp_adj = {g: list(adj[g]) for g in V4_ELEMS}
        for g in V4_ELEMS:
            random.shuffle(temp_adj[g])
            
        curr = start_node
        path = [curr]
        while temp_adj[curr]:
            nxt = temp_adj[curr].pop()
            path.append(nxt)
            curr = nxt
            
        if len(path) == N and path[-1] == end_node:
            return path, attempt
            
    raise RuntimeError(f"Eulerian-Shuffle nach {max_attempts} Versuchen fehlgeschlagen.")

primes_new=sieve_primes_range(100000,500000)
N_new=len(primes_new)
SECTOR_MAP={1:'E',5:'A',7:'B',11:'C'}
seq_new=[SECTOR_MAP[p%12] for p in primes_new]
def counts(sequence):
    C={g:{h:0 for h in V4_ELEMS} for g in V4_ELEMS}
    for i in range(len(sequence)-1): C[sequence[i]][sequence[i+1]]+=1
    return C
C_obs=counts(seq_new)
S_obs=sum(omega_table[seq_new[i],seq_new[i+1],seq_new[i+2]] for i in range(N_new-2))
K_count=0
total_attempts=0
sum_S_null=0
with (root/'null_replicates.csv').open('w') as f:
    f.write('replicate,S,attempts\n')
    for b in range(1,B_REPS+1):
        shuffled_seq,att=generate_eulerian_shuffle_strict(seq_new)
        total_attempts+=att
        assert len(shuffled_seq)==N_new and shuffled_seq[0]==seq_new[0] and shuffled_seq[-1]==seq_new[-1]
        assert counts(shuffled_seq)==C_obs, 'Bigram-Invarianz verletzt'
        S_b=sum(omega_table[shuffled_seq[i],shuffled_seq[i+1],shuffled_seq[i+2]] for i in range(N_new-2))
        sum_S_null+=S_b
        if S_b<=S_obs: K_count+=1
        f.write(f'{b},{S_b},{att}\n')
        if b%1000==0:
            f.flush()
            print(f'Progress {b}/{B_REPS}; elapsed {time.monotonic()-started:.1f}s',flush=True)
result=dict(N=N_new,start=seq_new[0],end=seq_new[-1],S_obs=S_obs,omega_obs=S_obs/(N_new-2),
 K=K_count,p_numerator=1+K_count,p_denominator=B_REPS+1,p_less=(1+K_count)/(B_REPS+1),
 replication_criterion_met=K_count<=99,sum_S_null=sum_S_null,null_mean_S=sum_S_null/B_REPS,
 total_attempts=total_attempts,mean_attempts=total_attempts/B_REPS,C_obs=C_obs,
 elapsed_seconds=time.monotonic()-started,all_invariance_checks_passed=True)
(root/'result.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2),flush=True)
