
document.querySelectorAll('.gate').forEach(gate => {
  gate.addEventListener('click', () => {
    const state = gate.dataset.state;
    const text = gate.querySelector('em');
    if (state === 'open') {
      gate.classList.toggle('expanded');
      text.textContent = gate.classList.contains('expanded') ? 'OPEN · proof required' : 'OPEN';
    }
  });
});
