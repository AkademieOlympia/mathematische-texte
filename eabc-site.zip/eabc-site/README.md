# EABC Research Program Website

Statische Website für das EABC / E8 Forschungsprogramm.

## Starten

Einfach `index.html` im Browser öffnen.

## Dateien

- `index.html` — Inhalt und Struktur
- `styles.css` — Design
- `script.js` — kleine Interaktionen

MathJax wird über CDN geladen. Für vollständig offline Betrieb kann MathJax später lokal eingebunden werden.
