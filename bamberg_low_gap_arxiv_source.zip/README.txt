Bamberg Low-Gap Protection — bilingual arXiv source

Files
-----
bamberg_low_gap_bilingual.tex
references.bib

Suggested compile
-----------------
pdflatex bamberg_low_gap_bilingual.tex
bibtex bamberg_low_gap_bilingual
pdflatex bamberg_low_gap_bilingual.tex
pdflatex bamberg_low_gap_bilingual.tex

Scientific status encoded in the source
---------------------------------------
L4: PROVED
L9: PROVED
L36: REDUCED TO 6 GLOBAL DIOPHANTINE CASES

Note
----
The source is intentionally conservative: L36 is not stated as proved.
