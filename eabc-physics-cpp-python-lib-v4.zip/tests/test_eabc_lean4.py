import unittest
import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import numpy as np
import sympy as sp
from eabc import QuantumGravityEngine, SymPyBinomialVerifier

class TestEABCLean4Theorems(unittest.TestCase):
    def setUp(self):
        self.engine = QuantumGravityEngine()

    def test_lean4_galois_norm_phi(self):
        phi = (1.0 + np.sqrt(5.0)) / 2.0
        phi_hat = 1.0 - phi
        norm = phi * phi_hat
        self.assertAlmostEqual(norm, -1.0, places=12)

    def test_lean4_galois_discriminant_five(self):
        phi = (1.0 + np.sqrt(5.0)) / 2.0
        phi_hat = 1.0 - phi
        disc = (phi - phi_hat)**2
        self.assertAlmostEqual(disc, 5.0, places=12)

    def test_lean4_invariant_I_vanishing(self):
        phi = (1.0 + np.sqrt(5.0)) / 2.0
        phi_hat = 1.0 - phi
        inv_I = (phi - 1.0) * (phi_hat - 1.0) + 1.0
        self.assertAlmostEqual(inv_I, 0.0, places=12)

    def test_spin7_fano_coupling_ratio(self):
        ratio = self.engine.evaluate_coupling_ratio()
        self.assertAlmostEqual(ratio, -5.0 / 3.0, places=12)

    def test_spin7_rg_beta_vanishing(self):
        res = self.engine.query_physics("spin7")
        self.assertEqual(res["beta_function"], 0.0)

    def test_topos_sieve_evaluation(self):
        p1 = self.engine.check_sieve_pass(0.9995)
        self.assertTrue(p1["pass"])
        self.assertEqual(p1["sieve"], "1_Omega")

        p2 = self.engine.check_sieve_pass(0.985)
        self.assertFalse(p2["pass"])
        self.assertEqual(p2["sieve"], "0_Omega")

class TestEABCSymbolicBinomials(unittest.TestCase):
    def test_sympy_fixpoint_binomials(self):
        res = SymPyBinomialVerifier.verify_galois_fixpoint()
        self.assertAlmostEqual(res['bin1_sum_sq'], 1.0, places=12)
        self.assertAlmostEqual(res['bin2_diff_sq_DK'], 5.0, places=12)
        self.assertAlmostEqual(res['bin3_minkowski'], np.sqrt(5.0), places=12)
        self.assertAlmostEqual(res['invariant_I'], 0.0, places=12)

if __name__ == "__main__":
    unittest.main()
